# Raw Circuit Board

![Not sushi.](oredict:oc:materialCircuitBoardRaw)

粗电路板，中间合成材料, 用来合成 [电路板](circuitBoard.md) (或者是 [印刷电路板](printedCircuitBoard.md)).
