# 经验升级

![This makes no sense, but it's cool.](oredict:oc:experienceUpgrade)

允许 [机器人](../block/robot.md) and [无人机](drone.md) 通过杀死怪物和挖矿收经验，每个升级存30级经验, 并且每一级都有加成，例如挖矿加速

[机器人](../block/robot.md) 10机得到金子, [robots](../block/robot.md)20级得到钻石

经验存在升级里面，认升级不认设备
