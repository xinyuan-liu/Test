# Inventory Controller

![I'm in control.](oredict:oc:inventoryControllerUpgrade)

物品栏控制器为[机器人](../block/robot.md) 和 [无人机](drone.md)提供了额外的物品栏交互能力. 允许在丢下或者捡起物品时显式指定一个外部的物品栏. 允许设备读取详细的物品信息. 最后他还给 [机器人](../block/robot.md) 添加了一个不借助外力更换自身装备的途径.

可以被放在 [适配器](../block/adapter.md), 为[适配器](../block/adapter.md) 提供了探测相邻方块的物品的能力. 但是不能捡起或者丢出物品。

另见: [转置器](../block/transposer.md)
