#区块加载升级

![Not going anywhere.](oredict:oc:chunkloaderUpgrade)

可以被安装在任意设备(如[机器人](../block/robot.md) 和 [微控制器](../block/microcontroller.md)) 来允许他加载所在的区块和相邻的区块. 这消耗能源，可以被组件API开关.

设备启动时自动启用, 在关机时自动停止.
