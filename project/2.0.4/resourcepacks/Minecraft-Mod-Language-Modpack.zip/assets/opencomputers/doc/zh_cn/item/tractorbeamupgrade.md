# Tractor Beam

![Beam me up.](oredict:oc:tractorBeamUpgrade)

牵引光束升级允许设备捡起3格内的物品. 对农场里面的[机器人](../block/robot.md)十分有用，当机器人使用范围挖掘工具时效果也很明显. 每次操作都会耗费能量.
