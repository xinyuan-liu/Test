# Network Card

![Enter the network.](oredict:oc:lanCard)

网卡允许 [电脑](../general/computer.md) 在本地网络内收发消息. 消息(或者封包) 可向子网广播, 或者是投送至特定的网络地址. [中继器](../block/relay.md) 可以用来桥接不同的子网，使之互相通信.
