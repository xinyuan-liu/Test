# E2PROM

![Let's get this party started.](oredict:oc:eeprom)

包含了电脑的启动代码，相当于BIOS，数据存储于raw 字节数组，需要编译烧写
E2PROM 被用于电脑的开机启动 [无人机](drone.md) 和 [单片机](../block/microcontroller.md).
